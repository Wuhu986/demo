package com.example.demo.config;

import com.example.demo.utils.JwtUtil;
import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

@Component
public class JwtFilter extends OncePerRequestFilter {

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain)
            throws ServletException, IOException {

        String token = request.getHeader("Authorization");

        if (token != null && token.startsWith("Bearer ")) {
            token = token.substring(7); // 去掉 Bearer 前缀

            try {
                Long userId = JwtUtil.getUserId(token);
                request.setAttribute("userId", userId); // 放入请求上下文，后续接口可以使用
            } catch (Exception e) {
                // Token 无效或过期
                response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
                response.getWriter().write("未登录或Token失效，请重新登录");
                return;
            }
        } else {
            // 没有Token，直接拦截
            response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            response.getWriter().write("请先登录");
            return;
        }

        filterChain.doFilter(request, response); // 放行
    }
}