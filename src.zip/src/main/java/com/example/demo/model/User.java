package com.example.demo.model;

import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.Data;

@Data
@TableName("user")
public class User {
    @TableId
    private Long id;
    private String nickname;
    private String phone;
    private String password;
    private String avatar;
    private String gender;
    private String birth;
    private String email;
    private String createTime;
    private String updateTime;

}
